package com.codetest.nexer.service;

import com.codetest.nexer.data.Book;
import com.codetest.nexer.data.NexerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.sql.Date;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class NexerServiceTest {
    @Mock
    private NexerRepository mockNexerRepository;

    private NexerService nexerService;

    private Book book1;
    private Book book2;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        book1 = new Book("B1", "Author 1", "Book 1", "Fiction", "9.99", new Date(2000, 1, 1), "This is a book about ...");
        book2 = new Book("B2", "Author 2", "Book 2", "Non-Fiction", "12.99", new Date(2001, 1, 1), "Description 2");
        List<Book> books = new ArrayList<>();
        books.add(book2);
        books.add(book1);
        when(mockNexerRepository.findAll()).thenReturn(books);
        nexerService = new NexerService(mockNexerRepository);

    }

    @Test
    void getAllBooks() {
        List<Book> result = nexerService.getAllBooks();

        verify(mockNexerRepository, times(1)).findAll();

        assertEquals(2, result.size());
        assertTrue(result.contains(book1));
        assertTrue(result.contains(book2));
    }

    @Test
    void getAllBooksSortedById() {
        List<Book> result = nexerService.getAllBooksSortedById();

        verify(mockNexerRepository, times(1)).findAll();

        assertEquals(2, result.size());
        assertEquals(book1, result.get(0));
        assertEquals(book2, result.get(1));
    }

    @Test
    void getBooksById() {
        String bookId = "B";
        List<Book> expectedBooks = Arrays.asList(book1, book2);

        when(mockNexerRepository.findBooksContainingBookId(bookId)).thenReturn(expectedBooks);

        List<Book> actualBooks = nexerService.getBooksById(bookId);

        verify(mockNexerRepository, times(1)).findBooksContainingBookId(bookId);

        assertEquals(expectedBooks.size(), actualBooks.size());
        assertEquals(expectedBooks.get(0), actualBooks.get(0));
        assertEquals(expectedBooks.get(1), actualBooks.get(1));
    }

    @Test
    void getAllByAuthor() {
        List<Book> expectedBooks = Arrays.asList(book1, book2);

        when(mockNexerRepository.findAll(Sort.by("author"))).thenReturn(expectedBooks);

        List<Book> result = nexerService.getAllByAuthor();

        verify(mockNexerRepository, times(1)).findAll(Sort.by("author"));

        assertEquals(2, result.size());
        assertEquals(book1, result.get(0));
        assertEquals(book2, result.get(1));
    }

    @Test
    void getAllByAuthorName() {
        List<Book> expectedBooks = Collections.singletonList(book1);

        when(mockNexerRepository.findBooksContainingAuthor("Author 1")).thenReturn(expectedBooks);

        List<Book> result = nexerService.getAllByAuthorName("Author 1");

        verify(mockNexerRepository, times(1)).findBooksContainingAuthor("Author 1");

        assertEquals(1, result.size());
        assertEquals(book1, result.get(0));
    }

    @Test
    void getAllByTitle() {
        List<Book> expectedBooks = Arrays.asList(book1, book2);

        when(mockNexerRepository.findAll(Sort.by("title"))).thenReturn(expectedBooks);

        List<Book> result = nexerService.getAllByTitle();

        verify(mockNexerRepository, times(1)).findAll(Sort.by("title"));

        assertEquals(2, result.size());
        assertEquals(book1, result.get(0));
        assertEquals(book2, result.get(1));
    }

    @Test
    void getAllByTitleName() {
        List<Book> expectedBooks = Collections.singletonList(book2);

        when(mockNexerRepository.findBooksContainingTitle("Book 2")).thenReturn(expectedBooks);

        List<Book> result = nexerService.getAllByTitleName("Book 2");

        verify(mockNexerRepository, times(1)).findBooksContainingTitle("Book 2");

        assertEquals(1, result.size());
        assertEquals(book2, result.get(0));
    }

    @Test
    void getAllByGenre() {
        List<Book> expectedBooks = Arrays.asList(book1, book2);

        when(mockNexerRepository.findAll(Sort.by("genre"))).thenReturn(expectedBooks);

        List<Book> result = nexerService.getAllByGenre();

        verify(mockNexerRepository, times(1)).findAll(Sort.by("genre"));

        assertEquals(2, result.size());
        assertEquals(book1, result.get(0));
        assertEquals(book2, result.get(1));
    }

    @Test
    void getAllByGenreName() {
        List<Book> expectedBooks = Collections.singletonList(book2);

        when(mockNexerRepository.findBooksContainingGenre("Non-Fiction")).thenReturn(expectedBooks);

        List<Book> result = nexerService.getAllByGenreName("Non-Fiction");

        verify(mockNexerRepository, times(1)).findBooksContainingGenre("Non-Fiction");

        assertEquals(1, result.size());
        assertEquals(book2, result.get(0));
    }

    @Test
    void getAllByPrice() {
        List<Book> expectedBooks = Arrays.asList(book1, book2);

        when(mockNexerRepository.findAllOrderByPrice()).thenReturn(expectedBooks);

        List<Book> result = nexerService.getAllByPrice();

        verify(mockNexerRepository, times(1)).findAllOrderByPrice();

        assertEquals(2, result.size());
        assertEquals(book1, result.get(0));
        assertEquals(book2, result.get(1));
    }

    @Test
    void getAllByPriceOrPriceRange_betweenPrices() {
        List<Book> expectedBooks = Collections.singletonList(book2);

        when(mockNexerRepository.findByPriceBetween(10.0, 15.0)).thenReturn(expectedBooks);

        List<Book> result = nexerService.getAllByPriceOrPriceRange("10.0&15.0");

        verify(mockNexerRepository, times(1)).findByPriceBetween(10.0, 15.0);

        assertEquals(1, result.size());
        assertEquals(book2, result.get(0));
    }
    @Test
    void getAllByPriceOrPriceRange_specificPrice() {
        List<Book> expectedBooks = Collections.singletonList(book1);

        when(mockNexerRepository.findAllSpecificPrice(9.99)).thenReturn(expectedBooks);

        List<Book> result = nexerService.getAllByPriceOrPriceRange("9.99");

        verify(mockNexerRepository, times(1)).findAllSpecificPrice(9.99);

        assertEquals(1, result.size());
        assertEquals(book1, result.get(0));
    }

    @Test
    void getAllOrderByPublishedDate() {
        List<Book> expectedBooks = Arrays.asList(book1, book2);

        when(mockNexerRepository.findAllByOrderByPublishDateAsc()).thenReturn(expectedBooks);

        List<Book> result = nexerService.getAllOrderByPublishedDate();

        verify(mockNexerRepository, times(1)).findAllByOrderByPublishDateAsc();

        assertEquals(2, result.size());
        assertEquals(book1, result.get(0));
        assertEquals(book2, result.get(1));
    }

    @Test
    void getAllByPublishDateYear() {
        List<Book> expectedBooks = Collections.singletonList(book1);

        when(mockNexerRepository.findAllByPublishDateYear("2000")).thenReturn(expectedBooks);

        List<Book> result = nexerService.getAllByPublishDateYear("2000");

        verify(mockNexerRepository, times(1)).findAllByPublishDateYear("2000");

        assertEquals(1, result.size());
        assertEquals(book1, result.get(0));
    }

    @Test
    void getAllByPublishDateYearMonth() {
        List<Book> expectedBooks = Collections.singletonList(book1);

        when(mockNexerRepository.findAllByPublishDateYearMonth("2000", "01")).thenReturn(expectedBooks);

        List<Book> result = nexerService.getAllByPublishDateYearMonth("2000", "1");

        verify(mockNexerRepository, times(1)).findAllByPublishDateYearMonth("2000", "01");

        assertEquals(1, result.size());
        assertEquals(book1, result.get(0));
    }

    @Test
    void getAllByPublishDateYearMonthDay() {
        List<Book> expectedBooks = Collections.singletonList(book2);

        when(mockNexerRepository.findAllByPublishDateYearMonthDay("2001", "01", "01")).thenReturn(expectedBooks);

        List<Book> result = nexerService.getAllByPublishDateYearMonthDay("2001", "1", "1");

        verify(mockNexerRepository, times(1)).findAllByPublishDateYearMonthDay("2001", "01", "01");

        assertEquals(1, result.size());
        assertEquals(book2, result.get(0));
    }

    @Test
    void getAllByDescription() {
        List<Book> expectedBooks = Arrays.asList(book2, book1);

        when(mockNexerRepository.findAll(Sort.by("description"))).thenReturn(expectedBooks);

        List<Book> result = nexerService.getAllByDescription();

        verify(mockNexerRepository, times(1)).findAll(Sort.by("description"));

        assertEquals(2, result.size());
        assertEquals(book2, result.get(0));
        assertEquals(book1, result.get(1));
    }

    @Test
    void getAllByDescriptionWord() {
        List<Book> expectedBooks = Collections.singletonList(book2);

        when(mockNexerRepository.findBooksContainingDescription("description")).thenReturn(expectedBooks);

        List<Book> result = nexerService.getAllByDescriptionWord("description");

        verify(mockNexerRepository, times(1)).findBooksContainingDescription("description");

        assertEquals(1, result.size());
        assertEquals(book2, result.get(0));
    }

    @Test
    void updateBook_bookNotFound() {
        String bookId = "B2";
        Book newBook = new Book("B1", "Author 1", "Book 1", "Fiction", "9.99", new Date(2000, 1, 1), "This is a book about ...");
        when(mockNexerRepository.findByBookId(bookId)).thenReturn(Optional.empty());

        ResponseEntity<Book> response = nexerService.updateBook(bookId, newBook);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    void updateBook_bookFound() {
        String bookId = "B1";
        Book newBook = new Book("B1", "Author 2", "Book 2", "Non-Fiction", "12.99", new Date(2001, 1, 1), "This is a book about....");
        Book oldBook = new Book("B1", "Author 1", "Book 1", "Fiction", "9.99", new Date(2000, 1, 1), "This is a book about ...");
        when(mockNexerRepository.findByBookId(bookId)).thenReturn(Optional.of(oldBook));
        when(mockNexerRepository.save(oldBook)).thenReturn(newBook);

        ResponseEntity<Book> response = nexerService.updateBook(bookId, newBook);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(newBook, response.getBody());
    }

    @Test
    void updateBook_bookUpdated() {
        String bookId = "B1";
        Book newBook = new Book("B1", "Author 2", "Book 2", "Non-Fiction", "12.99", new Date(2001, 1, 1), "This is a book about....");
        Book oldBook = new Book("B1", "Author 1", "Book 1", "Fiction", "9.99", new Date(2000, 1, 1), "This is a book about ...");
        when(mockNexerRepository.findByBookId(bookId)).thenReturn(Optional.of(oldBook));
        when(mockNexerRepository.save(oldBook)).thenReturn(newBook);

        ResponseEntity<Book> response = nexerService.updateBook(bookId, newBook);

        assertEquals(newBook.getAuthor(), oldBook.getAuthor());
        assertEquals(newBook.getTitle(), oldBook.getTitle());
        assertEquals(newBook.getGenre(), oldBook.getGenre());
        assertEquals(newBook.getPrice(), oldBook.getPrice());
        assertEquals(newBook.getPublishDate(), oldBook.getPublishDate());
        assertEquals(newBook.getDescription(), oldBook.getDescription());
    }

    @Test
    void addBook() {
        Book newBook = new Book();
        when(mockNexerRepository.save(newBook)).thenReturn(newBook);

        ResponseEntity<Book> responseEntity = nexerService.addBook(newBook);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
        assertTrue(responseEntity.getBody().getId().startsWith("B"));
    }
}
