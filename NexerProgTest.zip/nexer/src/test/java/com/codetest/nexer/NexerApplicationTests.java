package com.codetest.nexer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NexerApplicationTests {

	@Test
	void contextLoads() {
	}

}
