package com.codetest.nexer.data;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface NexerRepository extends JpaRepository<Book, Long> {
    Optional<Book> findByBookId(String bookId);

    @Query(value = "SELECT b FROM Book b WHERE LOWER(b.bookId) LIKE LOWER(CONCAT('%', ?1, '%')) ORDER BY b.bookId")
    List<Book> findBooksContainingBookId(String bookId);

    @Query(value = "SELECT b FROM Book b WHERE LOWER(b.author) LIKE LOWER(CONCAT('%', ?1, '%')) ORDER BY b.author")
    List<Book> findBooksContainingAuthor(String name);

    @Query(value = "SELECT b FROM Book b WHERE LOWER(b.title) LIKE LOWER(CONCAT('%', ?1, '%')) ORDER BY b.title")
    List<Book> findBooksContainingTitle(String name);

    @Query(value = "SELECT b FROM Book b WHERE LOWER(b.genre) LIKE LOWER(CONCAT('%', ?1, '%')) ORDER BY b.genre")
    List<Book> findBooksContainingGenre(String name);

    @Query(value = "SELECT * FROM book ORDER BY CAST(price AS DOUBLE) ASC", nativeQuery = true)
    List<Book> findAllOrderByPrice();

    @Query(value = "SELECT * FROM book WHERE CAST(price AS DOUBLE) = ?1 ORDER BY CAST(price AS DOUBLE) ASC", nativeQuery = true)
    List<Book> findAllSpecificPrice(Double price);

    @Query(value = "SELECT * FROM book WHERE CAST(price AS DOUBLE) BETWEEN ?1 AND ?2 ORDER BY CAST(price AS DOUBLE) ASC", nativeQuery = true)
    List<Book> findByPriceBetween(Double minPrice, Double maxPrice);

    List<Book> findAllByOrderByPublishDateAsc();

    @Query(value = "SELECT * " +
            "FROM Book " +
            "WHERE " +
            "PARSEDATETIME(publish_date, 'yyyy-MM-dd') >= PARSEDATETIME(CONCAT(?1, '-01-01'), 'yyyy-MM-dd') " +
            "AND " +
            "PARSEDATETIME(publish_date, 'yyyy-MM-dd') <= PARSEDATETIME(CONCAT(?1, '-12-31'), 'yyyy-MM-dd') " +
            "ORDER BY " +
            "PARSEDATETIME(publish_date, 'yyyy-MM-dd')", nativeQuery = true)
    List<Book> findAllByPublishDateYear(String year);

    @Query(value = "SELECT * " +
            "FROM Book " +
            "WHERE " +
            "PARSEDATETIME(publish_date, 'yyyy-MM-dd') >= PARSEDATETIME(CONCAT(?1, '-', ?2, '-01'), 'yyyy-MM-dd') " +
            "AND " +
            "PARSEDATETIME(publish_date, 'yyyy-MM-dd') <= PARSEDATETIME(CONCAT(?1, '-', ?2, '-31'), 'yyyy-MM-dd') " +
            "ORDER BY " +
            "PARSEDATETIME(publish_date, 'yyyy-MM-dd')", nativeQuery = true)
    List<Book> findAllByPublishDateYearMonth(String year, String month);

    @Query(value = "SELECT * " +
            "FROM Book " +
            "WHERE " +
            "PARSEDATETIME(publish_date, 'yyyy-MM-dd') = PARSEDATETIME(CONCAT(?1, '-', ?2, '-', ?3), 'yyyy-MM-dd') " +
            "ORDER BY " +
            "PARSEDATETIME(publish_date, 'yyyy-MM-dd')", nativeQuery = true)
    List<Book> findAllByPublishDateYearMonthDay(String year, String month, String day);

    @Query(value = "SELECT b FROM Book b WHERE LOWER(b.description) LIKE LOWER(CONCAT('%', ?1, '%')) ORDER BY b.description")
    List<Book> findBooksContainingDescription(String word);
}
