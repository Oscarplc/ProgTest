package com.codetest.nexer.data;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;

import java.sql.Date;

@Entity
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(columnDefinition = "VARCHAR(255)", nullable = false, unique = true)
    private String bookId;
    private String author;
    private String title;
    private String genre;
    private String price;
    @JsonProperty("publish_date")
    private Date publishDate;
    @Column(name = "description", length = 1000)
    private String description;

    public Book() {}
    public Book(String bookId, String author, String title, String genre, String price, Date publishDate, String description) {
        this.bookId = bookId;
        this.author = author;
        this.title = title;
        this.genre = genre;
        this.price = price;
        this.publishDate = publishDate;
        this.description = description;
    }
    public String getId() { return bookId; }
    public void setId(String bookId) { this.bookId = bookId; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }
    public String getPrice() { return price; }
    public void setPrice(String price) { this.price = price; }
    public Date getPublishDate() { return publishDate; }
    public void setPublishDate(Date publishDate) { this.publishDate = publishDate; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
