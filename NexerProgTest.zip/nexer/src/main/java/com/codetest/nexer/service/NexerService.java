package com.codetest.nexer.service;

import com.codetest.nexer.data.Book;
import com.codetest.nexer.data.NexerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NexerService {

    @Autowired
    private final NexerRepository nexerRepository;

    public NexerService(NexerRepository nexerRepository) {
        this.nexerRepository = nexerRepository;
    }

    public List<Book> getAllBooks() {
        return nexerRepository.findAll();
    }
    public List<Book> getAllBooksSortedById() {
        return sortListBooksByBookId(nexerRepository.findAll());
    }

    public List<Book> getBooksById(String bookId) {
        List<Book> books = nexerRepository.findBooksContainingBookId(bookId);
        return sortListBooksByBookId(books);
    }

    private List<Book> sortListBooksByBookId(List<Book> books) {
        books.sort((b1, b2) -> {
            String id1 = b1.getId();
            String id2 = b2.getId();
            String numericPart1 = id1.replaceAll("\\D+", "");
            String numericPart2 = id2.replaceAll("\\D+", "");
            int num1 = Integer.parseInt(numericPart1);
            int num2 = Integer.parseInt(numericPart2);
            return Integer.compare(num1, num2);
        });
        return books;
    }

    public List<Book> getAllByAuthor() {
        return nexerRepository.findAll(Sort.by( "author"));
    }

    public List<Book> getAllByAuthorName(String name) {
        return nexerRepository.findBooksContainingAuthor(name);
    }

    public List<Book> getAllByTitle() {
        return nexerRepository.findAll(Sort.by( "title"));
    }

    public List<Book> getAllByTitleName(String name) {
        return nexerRepository.findBooksContainingTitle(name);
    }

    public List<Book> getAllByGenre() {
        return nexerRepository.findAll(Sort.by( "genre"));
    }

    public List<Book> getAllByGenreName(String name) {
        return nexerRepository.findBooksContainingGenre(name);
    }

    public List<Book> getAllByPrice() {
        return nexerRepository.findAllOrderByPrice();
    }

    public List<Book> getAllByPriceOrPriceRange(String price) {
        List<Book> result;
        if (price.contains("&")) {
            String[] prices = price.split("&");
            Double minPrice = Double.parseDouble(prices[0]);
            Double maxPrice = Double.parseDouble(prices[1]);
            result = nexerRepository.findByPriceBetween(minPrice, maxPrice);
        } else {
            Double value = Double.parseDouble(price);
            result = nexerRepository.findAllSpecificPrice(value);
        }
        return result;
    }

    public List<Book> getAllOrderByPublishedDate() {
        return nexerRepository.findAllByOrderByPublishDateAsc();
    }

    public List<Book> getAllByPublishDateYear(String year) {
        return nexerRepository.findAllByPublishDateYear(year);
    }

    public List<Book> getAllByPublishDateYearMonth(String year, String month) {
        return nexerRepository.findAllByPublishDateYearMonth(year, formatTwoDigitDate(month));
    }

    public List<Book> getAllByPublishDateYearMonthDay(String year, String month, String day) {
        return nexerRepository.findAllByPublishDateYearMonthDay(year, formatTwoDigitDate(month), formatTwoDigitDate(day));
    }

    private String formatTwoDigitDate(String date) {
        int dateInt = Integer.parseInt(date);
        return String.format("%02d", dateInt);
    }

    public List<Book> getAllByDescription() {
        return nexerRepository.findAll(Sort.by("description"));
    }

    public List<Book> getAllByDescriptionWord(String word) {
        return nexerRepository.findBooksContainingDescription(word);
    }

    public ResponseEntity<Book> updateBook(String bookId, Book newBook) {
        Optional<Book> optionalBook = nexerRepository.findByBookId(bookId);
        if (optionalBook.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        Book book = optionalBook.get();
        book.setAuthor(newBook.getAuthor());
        book.setTitle(newBook.getTitle());
        book.setGenre(newBook.getGenre());
        book.setPrice(newBook.getPrice());
        book.setPublishDate(newBook.getPublishDate());
        book.setDescription(newBook.getDescription());
        Book savedBook = nexerRepository.save(book);
        return ResponseEntity.ok(savedBook);
    }

    public ResponseEntity<Book> addBook(Book book) {
        String bookId = "B" + getMaxBookId();
        book.setId(bookId);
        Book savedBook = nexerRepository.save(book);
        return ResponseEntity.ok(savedBook);
    }
    private int getMaxBookId() {
        int maxId = 0;
        List<Book> books = nexerRepository.findAll();
        for (Book book : books) {
            String bookId = book.getId();
            if (bookId != null && bookId.matches("^B\\d+$")) {
                int id = Integer.parseInt((bookId.substring(1)));
                if (id > maxId) {
                    maxId = id;
                }
            }
        }
        return maxId + 1;
    }
}
