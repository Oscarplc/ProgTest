package com.codetest.nexer;

import com.codetest.nexer.data.Book;
import com.codetest.nexer.data.NexerRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Component
public class DataLoader implements CommandLineRunner {
    /*
    Loads data into the database from resources/data.json
    Runs each time the application is started to make sure there is data to work with
     */
    @Autowired
    private NexerRepository nexerRepository;

    @Override
    public void run(String... args) {
        // Load data from JSON file
        ObjectMapper mapper = new ObjectMapper();
        TypeReference<List<Book>> typeReference = new TypeReference<>() {};
        InputStream inputStream = TypeReference.class.getResourceAsStream("/data.json");
        try {
            List<Book> books = mapper.readValue(inputStream, typeReference);
            for (Book book : books) {
                String id = book.getId();
                book.setId(id);
                // Check if book already in db
                if (nexerRepository.findByBookId(book.getId()).isPresent()) {
                    System.out.println("Ignoring duplicate book from json file with bookId: " + book.getId());
                    continue;
                }
                nexerRepository.save(book);
            }
            System.out.println("Data Loaded Successfully");
        } catch (IOException e) {
            System.out.println("Unable to load data: " + e.getMessage());
        }
    }
}
