package com.codetest.nexer.controllers;

import com.codetest.nexer.data.Book;
import com.codetest.nexer.service.NexerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class NexerController {

    private final NexerService nexerService;

    @Autowired
    public NexerController(NexerService nexerService) {
        this.nexerService = nexerService;
    }

    @GetMapping(value = "/books")
    public List<Book> getAllBooks() {
        return nexerService.getAllBooks();
    }

    @GetMapping(value = "/books/id")
    public List<Book> getAllBooksById() {
        return nexerService.getAllBooksSortedById();
    }

    @GetMapping(value = "/books/id/{bookId}")
    public List<Book> getBooksById(@PathVariable String bookId) {
        return nexerService.getBooksById(bookId);
    }

    @GetMapping(value = "/books/author")
    public List<Book> getAllByAuthor() {
        return nexerService.getAllByAuthor();
    }

    @GetMapping(value = "/books/author/{name}")
    public List<Book> getAllByAuthorName(@PathVariable String name) {
        return nexerService.getAllByAuthorName(name);
    }

    @GetMapping(value = "/books/title")
    public List<Book> getAllByTitle() {
        return nexerService.getAllByTitle();
    }

    @GetMapping(value = "/books/title/{name}")
    public List<Book> getAllByTitleName(@PathVariable String name) {
        return nexerService.getAllByTitleName(name);
    }

    @GetMapping(value = "/books/genre")
    public List<Book> getAllByGenre() {
        return nexerService.getAllByGenre();
    }

    @GetMapping(value = "/books/genre/{name}")
    public List<Book> getAllByGenreName(@PathVariable String name) {
        return nexerService.getAllByGenreName(name);
    }

    @GetMapping(value = "/books/price")
    public List<Book> getAllByPrice() {
        return nexerService.getAllByPrice();
    }
    @GetMapping(value = "/books/price/{price}")
    public List<Book> getByPrice(@PathVariable String price) {
        return nexerService.getAllByPriceOrPriceRange(price);
    }

    @GetMapping(value = "/books/published")
    public List<Book> getAllBooksOrderByPublishedDate() {
        return nexerService.getAllOrderByPublishedDate();
    }

    @GetMapping(value = "/books/published/{year}")
    public List<Book> getAllByPublishDateYear(@PathVariable String year) {
        return nexerService.getAllByPublishDateYear(year);
    }

    @GetMapping(value = "/books/published/{year}/{month}")
    public List<Book> getAllByPublishDateYearMonth(@PathVariable String year, @PathVariable String month) {
        return nexerService.getAllByPublishDateYearMonth(year, month);
    }

    @GetMapping(value = "/books/published/{year}/{month}/{day}")
    public List<Book> getAllByPublishDateYear(@PathVariable String year, @PathVariable String month, @PathVariable String day) {
        return nexerService.getAllByPublishDateYearMonthDay(year, month, day);
    }

    @GetMapping(value = "/books/description")
    public List<Book> getAllByDescription() {
        return nexerService.getAllByDescription();
    }

    @GetMapping(value = "/books/description/{word}")
    public List<Book> getAllByDescriptionWord(@PathVariable String word) {
        return nexerService.getAllByDescriptionWord(word);
    }

    @PostMapping(value = "/books/{bookId}")
    public ResponseEntity<Book> updateBook(@PathVariable String bookId, @RequestBody Book newBook) {
        return nexerService.updateBook(bookId, newBook);
    }

    @PutMapping(value = "/books")
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        return nexerService.addBook(book);
    }
}
